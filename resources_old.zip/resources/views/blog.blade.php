@include('Template_blog.header')

<!-- BLOG CONTENT -->
<div class="blog">
	<div class="container">
		<div class="row">
			<div class="col-md-9" style="overflow:hidden;">
				@foreach ($posts as $post)
					<article class="article-right">
						<div class="row">
							<div class="col-md-7">
								<img src="{{ asset($post->image) }}" class="img-responsive" alt=""/>
							</div>
							<div class="col-md-5">
								<h4><a href="#">{{$post->judul}}</a></h4>
								<div class="post-meta">
									<ul>
										<li><i class="fa fa-calendar-o"></i> {{ $post->created_date }}</li>
										<li><i class="fa fa-user"></i>{{ $post->user->name }}</li><br>
										<li><i class="fa fa-comments"></i> {{ $post->category->name }}</li>
									</ul>
								</div>
								<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aene.This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.</p>
								<p>Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis</p>
								<a class="rmore" href="#">read more</a>
							</div>
						</div>
					</article>
				@endforeach

				<div class="clearfix">
					<ul class="page_nav">
						{{ $posts->links() }}
					</ul>
				</div>
			</div>

{{-- widget --}}
@include('Template_blog.widget')
		</div>
	</div>
</div>
<!-- BLOG CONTENT -->

@include('template_blog.footer')
