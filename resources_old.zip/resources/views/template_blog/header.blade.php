<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
<head>

	<!-- Meta -->
	<meta charset="utf-8">
	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Candahar</title>

	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Favicons -->
	<link rel="shortcut icon" href="img/favicon.ico">
	<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="144x144" href="img/apple-touch-icon-144x144.png">

	<!-- CSS -->
	<link rel="stylesheet" href="{{ asset('public/frontend/css/bootstrap.css') }}">
	<link rel="stylesheet" href="{{ asset('public/frontend/css/isotope.css') }}">
	<link rel="stylesheet" href="{{ asset('public/frontend/css/style.css') }}">
	<link rel="stylesheet" href="{{ asset('public/frontend/js/owl-carousel/owl.carousel.css') }}">
	<link rel="stylesheet" href="{{ asset('public/frontend/js/owl-carousel/owl.theme.css') }}">
	<link rel="stylesheet" href="{{ asset('public/frontend/css/animate.css') }}">
	<link rel="stylesheet" href="{{ asset('public/frontend/css/prettyphoto.css') }}"/>

	<!-- Custom Fonts -->
	<link href="{{ asset('public/frontend/font-awesome-4.1.0/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,300italic,400italic,700,500,900' rel='stylesheet' type='text/css'>

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
      	<script src="./js/libs/html5shiv.js"></script>
	      <script src="./js/libs/respond.js"></script>
	<![endif]-->

</head>
<body>

<div class="body">

<!-- HEADER -->
<header data-stellar-background-ratio="0.5">
	<div class="container">
		<div class="col-md-12">
			<h2 class="logo"><img src="{{ asset('public/frontend/images/candahar_Logo.png') }}" style="height: 330px; width: 250px;" alt=""/></a></h2>
			<h2 class="font-alt-lite">Welcome to <span class="font-alt-bold">candahar</span></h2>
		</div>
	</div>
</header>
<!-- HEADER -->



<!-- NAVIGATION -->
<nav>
	<div class="container">
		<div class="row">
			<div class="col-md-10">
				<ul id="menu">
					<li><a href="./index.html">Home</a></li>
					<li><a href="./contact.html">Contact</a></li>
				</ul>
			</div>

		</div>
	</div>
</nav>
<!-- NAVIGATION -->
