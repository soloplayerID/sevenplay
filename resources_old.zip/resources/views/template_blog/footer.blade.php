<!-- FOOTER -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-3 footer-widget footer-widget1">
				<h4>Text Widget</h4>
				<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis</p>
				<p>auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh</p>
			</div>

			<div class="col-md-3 footer-widget footer-widget2">
				<h4>Recent Posts</h4>
				<ul class="rposts">
					<li><a href="#">New Search Platform Update</a></li>
					<li><a href="#">Envato's Most Wanted - $5,000 for Ghost Themes</a></li>
					<li><a href="#">Update: WordPress Theme Submission Requirements</a></li>
					<li><a href="#">Envato Staff Vs Community Nike+ competition</a></li>
				</ul>
			</div>

			<div class="col-md-3 footer-widget footer-widget3">
				<h4>Popular Tags</h4>
				<ul class="tags">
					<li><a href="#">web design</a></li>
					<li><a href="#">coding</a></li>
					<li><a href="#">wordpress</a></li>
					<li><a href="#">php</a></li>
					<li><a href="#">photography</a></li>
					<li><a href="#">woo commerce</a></li>
				</ul>
			</div>

			<div class="col-md-3 footer-widget footer-widget4">
				<h4>Flickr Gallery</h4>
				<ul id="flickr" class="thumbs"></ul>
			</div>
		</div>
	</div>
</footer>
<!-- FOOTER -->

<!-- FOOTER - COPYRIGHT -->
<div class="footer-bottom">
	<div class="container">
		<div class="col-md-6">
			<p>&copy; 2014 Ping. All Rights Reserved</p>
		</div>
		<div class="col-md-6">
			<ul class="footer-social">
				<li><a class="fa fa-google-plus" href="#"></a></li>
				<li><a class="fa fa-twitter" href="#"></a></li>
				<li><a class="fa fa-pinterest" href="#"></a></li>
				<li><a class="fa fa-dribbble" href="#"></a></li>
				<li><a class="fa fa-linkedin" href="#"></a></li>
				<li><a class="fa fa-facebook" href="#"></a></li>
			</ul>
		</div>
	</div>
</div>
<!-- FOOTER - COPYRIGHT -->

</div>

<!-- JavaScript -->
<script src="{{ asset('public/frontend/js/jquery.js') }}"></script>
<script src="{{ asset('public/frontend/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('public/frontend/js/jflickrfeed.min.js') }}"></script>
<script src="{{ asset('public/frontend/js/owl-carousel/owl.carousel.min.js') }}"></script>
<script src="{{ asset('public/frontend/js/jquery.isotope.min.js') }}"></script>
<script src="{{ asset('public/frontend/js/stellar.js') }}"></script>
<script src="{{ asset('public/frontend/js/animation.js') }}"></script>
<script src="{{ asset('public/frontend/js/jquery.prettyphoto.js') }}"></script>
<script src="{{ asset('public/frontend/js/jquery.nicescroll.js') }}"></script>
<script src="{{ asset('public/frontend/js/jquery.flexslider.js') }}"></script>
<script src="{{ asset('public/frontend/js/portfolio.js') }}"></script>
<script src="{{ asset('public/frontend/js/jquery.slicknav.min.js') }}"></script>
<script src="{{ asset('public/frontend/js/main.js') }}"></script>

</body>
</html>
