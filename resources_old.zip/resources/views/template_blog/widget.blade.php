<!-- SIDEBAR -->
<aside class="col-md-3">
  <div class="widget">
    <h5>Social Icons</h5>
    <ul class="social pull-left">
      <li><a class="fa fa-google-plus" href="#"></a></li>
      <li><a class="fa fa-twitter" href="#"></a></li>
      <li><a class="fa fa-pinterest" href="#"></a></li>
      <li><a class="fa fa-dribbble" href="#"></a></li>
      <li><a class="fa fa-linkedin" href="#"></a></li>
      <li><a class="fa fa-facebook" href="#"></a></li>
    </ul>
  </div>
  <div class="clearfix"></div>
  <div class="widget">
    <h5>Postingan terbaru</h5>
    <ul class="rposts1">
      @foreach ($recents as $recent)
        <li>
          <img src="{{ asset($recent->image) }}" style="width: 40px; height: 40px" alt=""/>
          <h4><a href="#">{{$recent->judul}}</a></h4>
        </li>
      @endforeach
    </ul>
  </div>
  <div class="clearfix"></div>
</aside>
